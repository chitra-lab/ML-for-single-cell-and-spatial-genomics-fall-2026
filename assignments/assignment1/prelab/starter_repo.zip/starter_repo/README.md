# ML for Single-Cell & Spatial Biology — Course Starter Repo

**Prof. Uthsav Chitra | Johns Hopkins University | Fall 2026**

## What's in this repo

```
starter_repo/
├── README.md           ← you are here
├── hello_lab.ipynb     ← Pre-Lab 1: run this to verify your setup
├── test_setup.py       ← Environment check script
└── .gitignore
```

## Pre-Lab 1 Instructions

Complete these steps **before coming to class**:

### Step 1: Install Python & Git
- Python 3.9+ from [python.org](https://python.org)
- Git from [git-scm.com](https://git-scm.com/downloads)

### Step 2: Install an AI coding assistant (recommended)
Choose one:
- **Claude Code**: `npm install -g @anthropic-ai/claude-code`
- **Codex**: see OpenAI docs
- Or use any AI assistant you're comfortable with

### Step 3: Make a GitHub account
- Go to [github.com](https://github.com) and sign up (free)
- Set your git config:
  ```bash
  git config --global user.name "Your Name"
  git config --global user.email "your.email@example.com"
  ```

### Step 4: Clone this repo
```bash
git clone <repo_url>  # your instructor will provide the URL
cd starter_repo
```

### Step 5: Install Python packages
```bash
pip install numpy pandas matplotlib scikit-learn scipy jupyter
```

### Step 6: Run the environment check
```bash
python test_setup.py
```
All checks should pass (green). If any fail, follow the printed fix instructions.

### Step 7: Run the hello notebook
```bash
jupyter notebook hello_lab.ipynb
```
Run all cells from top to bottom. You should see:
- A simple PCA plot on synthetic data
- A printed confirmation message

### Step 8: Commit and push
```bash
git add .
git commit -m "Completed pre-lab 1 setup"
git push
```

### Step 9: Submit
Submit your **GitHub repo link** on Canvas.

## Need help?
- Ask in the course Slack/Discord
- Use your AI assistant to debug errors
- Office hours: see course syllabus
