#!/usr/bin/env python3
"""
test_setup.py — Pre-Lab 1 Environment Check
=============================================
Run this script to verify your environment is ready for Lab 1.

Usage:
    python test_setup.py

If all checks pass, you'll see a green "All checks passed!" message.
If any check fails, follow the instructions printed to fix it.
"""

import sys
import subprocess

# ANSI colors
GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
RESET = "\033[0m"

passed = 0
failed = 0


def check(name, condition, fix_hint=""):
    global passed, failed
    if condition:
        print(f"  {GREEN}[PASS]{RESET} {name}")
        passed += 1
    else:
        print(f"  {RED}[FAIL]{RESET} {name}")
        if fix_hint:
            print(f"         {YELLOW}Fix:{RESET} {fix_hint}")
        failed += 1


def get_version(module_name):
    try:
        mod = __import__(module_name)
        return getattr(mod, "__version__", "installed (version unknown)")
    except ImportError:
        return None


print("=" * 50)
print("Pre-Lab 1: Environment Setup Check")
print("=" * 50)
print()

# --- Python version ---
print("1. Python")
py_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
check(
    f"Python {py_version} (need 3.9+)",
    sys.version_info >= (3, 9),
    "Install Python 3.9 or later from https://python.org",
)
print()

# --- Core packages ---
print("2. Core Packages")
packages = ["numpy", "pandas", "matplotlib", "sklearn", "scipy"]
for pkg in packages:
    ver = get_version(pkg)
    check(
        f"{pkg} {ver}" if ver else pkg,
        ver is not None,
        f"Run: pip install {pkg}",
    )
print()

# --- Jupyter ---
print("3. Jupyter Notebook")
try:
    result = subprocess.run(
        [sys.executable, "-m", "jupyter", "--version"],
        capture_output=True, text=True, timeout=10
    )
    check("Jupyter is installed", result.returncode == 0, "Run: pip install jupyter")
except Exception:
    check("Jupyter is installed", False, "Run: pip install jupyter")
print()

# --- Git ---
print("4. Git")
try:
    result = subprocess.run(["git", "--version"], capture_output=True, text=True, timeout=5)
    git_ok = result.returncode == 0
    git_ver = result.stdout.strip() if git_ok else ""
    check(git_ver if git_ok else "Git", git_ok, "Install Git from https://git-scm.com/downloads")
except Exception:
    check("Git", False, "Install Git from https://git-scm.com/downloads")
print()

# --- Git config ---
print("5. Git Configuration")
try:
    name_result = subprocess.run(["git", "config", "user.name"], capture_output=True, text=True)
    email_result = subprocess.run(["git", "config", "user.email"], capture_output=True, text=True)
    git_name = name_result.stdout.strip()
    git_email = email_result.stdout.strip()
    check(f"Git user.name: {git_name}" if git_name else "Git user.name not set",
          bool(git_name), "Run: git config --global user.name 'Your Name'")
    check(f"Git user.email: {git_email}" if git_email else "Git user.email not set",
          bool(git_email), "Run: git config --global user.email 'you@example.com'")
except Exception:
    check("Git configuration", False, "Make sure Git is installed first")
print()

# --- Optional: AI coding assistant ---
print("6. AI Coding Assistant (optional but recommended)")
# Check for common AI CLI tools
ai_tools = []
for tool in ["claude", "codex"]:
    try:
        result = subprocess.run([tool, "--version"], capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            ai_tools.append(tool)
    except Exception:
        pass

if ai_tools:
    check(f"Found: {', '.join(ai_tools)}", True)
else:
    check(
        "No AI CLI tool found (optional)",
        True,  # Not required, just a heads up
        "Consider installing Claude Code (npm install -g @anthropic-ai/claude-code) "
        "or Codex for help during labs",
    )
print()

# --- Summary ---
print("=" * 50)
if failed == 0:
    print(f"{GREEN}All checks passed! You're ready for Lab 1.{RESET}")
    print(f"{GREEN}Next: open hello_lab.ipynb in Jupyter and run all cells.{RESET}")
else:
    print(f"{RED}{failed} check(s) failed. Please fix them before Lab 1.{RESET}")
    print(f"{GREEN}{passed} check(s) passed.{RESET}")
print("=" * 50)

sys.exit(1 if failed > 0 else 0)
